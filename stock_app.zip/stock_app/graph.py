import pandas as pd
import matplotlib.pyplot as plt

# Load your data
data = pd.read_csv(r'C:\\Users\\Admin\\Desktop\\stock_app\\data\\Transworld Energy.csv')

# If there's only one column for stock value:
stock_values = data['Stock Value']

# Option 1: Increase the rolling window size to 1000
window_size = 1000  # Larger window for more smoothing
smoothed_values = stock_values.rolling(window=window_size).mean()

# Option 2: Downsample the data (every 50th point for example)
downsampled_data = stock_values[::50]

# Use a rolling window to smooth the downsampled data
smoothed_downsampled = downsampled_data.rolling(window=100).mean()

# Plot the smoothed and downsampled values
plt.figure(figsize=(12, 6))
plt.plot(smoothed_downsampled, color='b', linewidth=2, label=f'Smoothed Stock Value (Downsampled)')
plt.title('Downsampled and Smoothed Stock Price vs Time')
plt.xlabel('Time')
plt.ylabel('Price')
plt.grid(True)
plt.legend()
plt.show()
