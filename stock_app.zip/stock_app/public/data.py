import pandas as pd

# Load your data (replace with your actual file path)
data = pd.read_csv("C:\\Users\\Admin\\Desktop\\stock_app\\data\\Ramesh Retail.csv")

# Round the 'Stock Value' column to 2 decimal places
data['Stock Value'] = data['Stock Value'].round(2)

# Save the modified DataFrame back to the CSV file
data.to_csv("C:\\Users\\Admin\\Desktop\\stock_app\\data\\Ramesh Retail.csv", index=False)

# Display the updated DataFrame to verify changes (optional)
print(data.head())
