import pandas as pd
import numpy as np

# Load the CSV file
file_path = "C:\\Users\\Admin\\Desktop\\stock_app\\data\\Transworld Energy.csv"  # Replace with your file path
data = pd.read_csv(file_path)

# Ensure the column is named correctly
data.columns = ['Stock Value']

# Rolling average to smoothen the fluctuations over a 60-second window (can adjust)
data['Smoothed Value'] = data['Stock Value'].rolling(window=60, min_periods=1).mean()

# Function to simulate trends (upward, downward, stable, volatile)
def simulate_trend_patterns(smoothed_values):
    new_values = []
    trend_length = len(smoothed_values)
    
    for i, price in enumerate(smoothed_values):
        # Upward trend: steady growth (10% of the total data)
        if i < int(0.1 * trend_length):
            change = np.random.uniform(0.001, 0.003)  # Small positive change (0.1% to 0.3%)
        
        # Downward trend: steady decline (10% of the total data)
        elif int(0.1 * trend_length) <= i < int(0.2 * trend_length):
            change = np.random.uniform(-0.003, -0.001)  # Small negative change (-0.3% to -0.1%)
        
        # Stable period: minor fluctuations (40% of the total data)
        elif int(0.2 * trend_length) <= i < int(0.6 * trend_length):
            change = np.random.uniform(-0.001, 0.001)  # Almost no change
        
        # Volatile event: sharp rise (10% of the total data)
        elif int(0.6 * trend_length) <= i < int(0.7 * trend_length):
            change = np.random.uniform(0.01, 0.05)  # Larger positive change (1% to 5%)
        
        # Volatile event: sharp fall (10% of the total data)
        elif int(0.7 * trend_length) <= i < int(0.8 * trend_length):
            change = np.random.uniform(-0.05, -0.01)  # Larger negative change (-5% to -1%)
        
        # Back to steady growth (20% of the total data)
        else:
            change = np.random.uniform(0.001, 0.002)  # Small positive change

        # Apply change and round to 2 decimal places
        price = price * (1 + change)
        price = round(price, 2)
        new_values.append(price)
    
    return new_values

# Apply the trend simulation
data['Patterned Stock Value'] = simulate_trend_patterns(data['Smoothed Value'])

# Save the modified dataset
data[['Patterned Stock Value']].to_csv('modified_transworld.csv', index=False)

# Print first few rows to check
print(data.head())
