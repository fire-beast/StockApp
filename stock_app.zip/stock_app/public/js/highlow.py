import pandas as pd

# Load the CSV file (use the file you generated with the modified prices)
file_path = 'C:\\Users\\Admin\\Desktop\\stock_app\\data\\Transworld Energy.csv'  # Replace with the correct file path
data = pd.read_csv(file_path)

# Ensure the column is named correctly (for patterned prices)
data.columns = ['Stock Value']

# Finding the required values
start_price = data['Stock Value'].iloc[0]  # First price (starting price)
end_price = data['Stock Value'].iloc[-1]   # Last price (ending price)
highest_price = data['Stock Value'].max()  # Maximum price (highest)
lowest_price = data['Stock Value'].min()   # Minimum price (lowest)

# Displaying the results
print(f"Start Price: {start_price}")
print(f"End Price: {end_price}")
print(f"Highest Price: {highest_price}")
print(f"Lowest Price: {lowest_price}")
