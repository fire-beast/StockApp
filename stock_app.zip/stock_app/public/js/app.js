let dps = []; // Data points for the chart
let chart = new CanvasJS.Chart("chartContainer", {
    title: { text: "Live Stock Prices" },
    data: [{ type: "line", dataPoints: dps }]
});
let xVal = 0; // Initialize x-value for data points
let updateInterval = 1000; // Update interval in milliseconds
let intervalId; // To store the interval ID for clearing it later

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM fully loaded and parsed');
    const submitButton = document.getElementById('submitButton'); 
    if (submitButton) {
        submitButton.addEventListener('click', () => {
            const selectedCompany = document.getElementById('companySelect').value;
            console.log("Selected company:", selectedCompany);
            updateChartForSelectedCompany(selectedCompany);
        });
    } else {
        console.error('Submit button not found in DOM');
    }
});
function updateChartForSelectedCompany(selectedCompany) {
    console.log("Function called with:", selectedCompany);
    
    // Clear the previous interval if it exists
    if (intervalId) {
        clearInterval(intervalId);
        intervalId = null;
    }
    
    // Clear the existing data points
    dps.length = 0;
    xVal = 0;
    chart.render(); // Render the empty chart
    
    if (!selectedCompany) {
        console.log("No company selected.");
        return; // Do nothing if no company is selected
    }
    
    // Fetch stock price immediately for the selected company
    fetchStockPrice(selectedCompany);
    
    // Set interval to update stock prices every second for the selected company
    intervalId = setInterval(() => {
        fetchStockPrice(selectedCompany);
    }, updateInterval);
}

function fetchStockPrice(selectedCompany) {
    console.log(`Fetching stock price for: ${selectedCompany}`);
    
    fetch('/stock-data') // Adjust the endpoint as necessary
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            const price = data[selectedCompany];
            if (price !== undefined) {
                const parsedPrice = parseFloat(price);
                dps.push({ x: xVal++, y: parsedPrice });
                
                // Limit data points to the last 20
                if (dps.length > 20) {
                    dps.shift();
                }
                
                chart.render(); // Render the updated chart
                console.log('Chart updated');
            } else {
                console.error(`Price for ${selectedCompany} is missing or invalid.`);
            }
        })
        .catch(error => console.error('Error fetching stock data:', error));
}
// Fetch stock prices for 10 companies from the backend and update every second
function fetchStockData() {
  fetch('/stock-data')
    .then(response => response.json())
    .then(data => {
      // Update the stock prices in the table
      Object.keys(data).forEach(company => {
        console.log(`${company.replace(/\s+/g, '-')}-price`)
        const priceElement = document.getElementById(`${company.replace(/\s+/g, '-')}-price`);
        if (priceElement) {
          priceElement.textContent = parseFloat(data[company]).toFixed(2);
        }
      });
    })
    .catch(error => {
      console.error('Error fetching stock data:', error);
    });
}

// Function to check if the market is open and update prices accordingly
function updatePricesIfMarketOpen() {
  if (isMarketOpen()) {
    fetchStockData();  // Fetch stock prices if the market is open
  }
}

// Format time as HH:MM AM/PM
function formatTime(date) {
  let hours = date.getHours();
  const minutes = date.getMinutes();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12 || 12;
  const minutesStr = minutes < 10 ? '0' + minutes : minutes;
  return hours + ':' + minutesStr + ' ' + ampm;
}

// Market is open from 10 AM to 6 PM
function isMarketOpen() {
  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();
  // Market is open from 10:30 AM to 3:00 PM
  return (hours === 10 && minutes >= 35) || (hours > 10 && hours < 15) || (hours === 15 && minutes === 0);
}

// Update the clock and handle market open/close
function updateClock() {
  const now = new Date();
  document.getElementById('currentTime').innerText = 'Current Time: ' + formatTime(now);
}

// Portfolio object to track holdings, funds, and buy prices
let portfolio = {
  cash: 5000, // Initial cash for each user
  stocks: {
    "IronOre": { quantity: 0, totalInvested: 0 },
    "Vedant Institute": { quantity: 0, totalInvested: 0 },
    "Ramesh Retail": { quantity: 0, totalInvested: 0 },
    "Global Link ISP": { quantity: 0, totalInvested: 0 },
    "AI Nexus Technologies": { quantity: 0, totalInvested: 0 },
    "InfoTech Technologies": { quantity: 0, totalInvested: 0 },
    "Avro India Limited": { quantity: 0, totalInvested: 0 },
    "Falcon Biotech": { quantity: 0, totalInvested: 0 },
    "Tomato": {quantity: 0, totalInvested: 0},
    "Transworld Energy": {quantity:0,totalInvested:0}
  },
  transactions: []
};
// Function to display transactions
function displayTransactions() {
  const transactionsContainer = document.getElementById('transactionsContainer');
  transactionsContainer.innerHTML = ''; // Clear previous content

  if (portfolio.transactions.length === 0) {
    transactionsContainer.innerHTML = '<p>No transactions found.</p>';
    return;
  }

  const table = document.createElement('table');
  table.innerHTML = `
    <tr>
      <th>Type</th>
      <th>Company</th>
      <th>Quantity</th>
      <th>Price</th>
      <th>Total</th>
      <th>Date</th>
    </tr>
  `;

  portfolio.transactions.forEach(transaction => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${transaction.type}</td>
      <td>${transaction.company}</td>
      <td>${transaction.quantity}</td>
      <td>${transaction.price.toFixed(2)}</td>
      <td>${transaction.total.toFixed(2)}</td>
      <td>${transaction.date}</td>
    `;
    table.appendChild(row);
  });

  transactionsContainer.appendChild(table);
}

// Attach the display function to the "My Transactions" button
document.getElementById('viewTransactions').addEventListener('click', displayTransactions);


// Function to update the portfolio table
function updatePortfolio() {
  const portfolioTable = document.getElementById('portfolioTable').getElementsByTagName('tbody')[0];
  portfolioTable.innerHTML = ''; // Clear existing rows
  for (let company in portfolio.stocks) {
    const row = portfolioTable.insertRow();
    row.insertCell(0).innerText = company;
    row.insertCell(1).innerText = portfolio.stocks[company].quantity;

    // Get the current price for the stock
    const currentPrice = parseFloat(document.getElementById(company.replace(/\s+/g, '-') + "-price").innerText);
    
    // Calculate total value based on quantity and current price
    const totalValue = (portfolio.stocks[company].quantity * currentPrice).toFixed(2);

    // Use totalInvested for display if quantity > 0
    const displayTotalValue = portfolio.stocks[company].quantity > 0 ? portfolio.stocks[company].totalInvested.toFixed(2) : totalValue;

    row.insertCell(2).innerText = displayTotalValue; // Insert the total value (or total invested)
  }
}
// Function to save portfolio to localStorage
function savePortfolio() {
  localStorage.setItem('portfolio', JSON.stringify(portfolio));
}

// Function to load portfolio from localStorage
function loadPortfolio() {
  const savedPortfolio = localStorage.getItem('portfolio');
  if (savedPortfolio) {
    const loadedPortfolio = JSON.parse(savedPortfolio);
    
    portfolio.cash = loadedPortfolio.cash;
    portfolio.transactions = loadedPortfolio.transactions; 

    // Load the stocks and quantities
    for (let company in loadedPortfolio.stocks) {
      if (portfolio.stocks[company]) {
        portfolio.stocks[company].quantity = loadedPortfolio.stocks[company].quantity;
        portfolio.stocks[company].totalInvested = loadedPortfolio.stocks[company].totalInvested;
      }
    }
  }
  console.log("Portfolio loaded:", portfolio);
}


// Function to save transactions to localStorage
function saveTransactions() {
  localStorage.setItem('transactions', JSON.stringify(portfolio.transactions));
}

// Function to load transactions from localStorage
function loadTransactions() {
  const savedTransactions = localStorage.getItem('transactions');
  if (savedTransactions) {
    portfolio.transactions = JSON.parse(savedTransactions);
    displayTransactions(); // Update the transactions list on the page
  }
}
// Function to buy stock
function buyStock(company) {
  if (!isMarketOpen()) {
    alert("Market is closed! No transactions allowed.");
    return;
  }
  const companyId = company.replace(/\s+/g, '-');
  const price = parseFloat(document.getElementById(companyId + "-price").innerText);
  const quantity = prompt(`Enter number of shares to buy for ${company}:`);
  if (quantity === null || isNaN(quantity) || quantity <= 0) {
    alert("Invalid quantity");
    return;
  }
  if (portfolio.cash >= price * quantity) {
    const stock = portfolio.stocks[company];
    stock.quantity += parseInt(quantity);
    stock.totalInvested += price * quantity; // Update total invested
    portfolio.cash -= price * quantity;
    portfolio.transactions.push({
      type: 'Buy',
      company: company,
      quantity: parseInt(quantity),
      price: price,
      total: price * quantity,
      date: new Date().toLocaleString() // Record the date/time of the transaction
    });
    savePortfolio();
    saveTransactions();
    updatePortfolio();
    updateCashDisplay();
    alert(`Bought ${quantity} shares of ${company} at $${price.toFixed(2)} per share.`);
  } else {
    alert("Not enough cash to buy.");
  }
}

// Function to sell stock
function sellStock(company) {
  if (!isMarketOpen()) {
    alert("Market is closed! No transactions allowed.");
    return;
  }
  const companyId = company.replace(/\s+/g, '-');
  const price = parseFloat(document.getElementById(companyId + "-price").innerText);
  const quantity = prompt(`Enter number of shares to sell for ${company}:`);
  if (quantity === null || isNaN(quantity) || quantity <= 0) {
    alert("Invalid quantity");
    return;
  }
  const stock = portfolio.stocks[company];
  const quantityToSell = parseInt(quantity);
  if (stock.quantity >= quantityToSell) {
    const averageInvestmentPerShare = stock.totalInvested / stock.quantity;
    const totalInvestedInSoldShares = averageInvestmentPerShare * quantityToSell;
    const saleRevenue = price * quantityToSell;
    const profitForThisSale = saleRevenue - totalInvestedInSoldShares;
    stock.quantity -= quantityToSell;
    stock.totalInvested -= totalInvestedInSoldShares;
    if (stock.quantity === 0) {
      stock.totalInvested = 0;
    }
    portfolio.cash += saleRevenue;
    portfolio.transactions.push({
      type: 'Sell',
      company: company,
      quantity: quantityToSell,
      price: price,
      total: saleRevenue,
      date: new Date().toLocaleString() // Record the date/time of the transaction
    });
    savePortfolio();
    saveTransactions();
    updatePortfolio();
    const profitMessage = profitForThisSale >= 0
      ? `Profit: $${profitForThisSale.toFixed(2)}`
      : `Loss: $${Math.abs(profitForThisSale).toFixed(2)}`;
    updateCashDisplay();
    alert(`Sold ${quantity} shares of ${company} at $${price.toFixed(2)} per share.\n${profitMessage}`);
  } else {
    alert("Not enough shares to sell.");
  }
}

// Calculate total profit and portfolio value
document.getElementById('calculateProfit').addEventListener('click', function() {
  let totalPortfolioValue = portfolio.cash;
  let totalStockValue = 0;
  let totalInvested = 0;
  let totalProfit = 0;
  for (let company in portfolio.stocks) {
    const companyId = company.replace(/\s+/g, '-');
    const currentPrice = parseFloat(document.getElementById(companyId + "-price").innerText);
    const stock = portfolio.stocks[company];
    if (stock && stock.quantity > 0) {
      const stockValue = stock.quantity * currentPrice;
      totalStockValue += stockValue;
      totalInvested += stock.totalInvested;
      const profitOrLoss = stockValue - stock.totalInvested;
      totalProfit += profitOrLoss;
    }
  }
  totalPortfolioValue += totalStockValue;
  const resultMessage = totalProfit >= 0
    ? `Profit: $${totalProfit.toFixed(2)}`
    : `Loss: $${Math.abs(totalProfit).toFixed(2)}`;
  document.getElementById('result').innerText = `Total Portfolio Value: $${totalPortfolioValue.toFixed(2)}`;
});

// Initialize stock prices on page load
window.onload = function() {
  //clearStorage();
  fetchStockData();
  loadPortfolio();      // Load portfolio from localStorage
  loadTransactions();   // Load transactions from localStorage
  updatePortfolio();
  updateClock();        // Update the market open/close status
  updateCashDisplay();
  fetchNews();
};

// Update clock and stock data every second
setInterval(updateClock, 1000);
setInterval(fetchStockData, 1000);
setInterval(updatePricesIfMarketOpen, 1000);
setInterval(fetchNews, 60000);
function goBack() {
  window.history.back();
}
function clearStorage() {
  localStorage.removeItem('portfolio');
  localStorage.removeItem('transactions');
  console.log("Storage cleared");
}


function updateCashDisplay() {
  const cashElement = document.getElementById('availableCash');
  if (cashElement) {
      cashElement.innerText = `Cash: $${portfolio.cash.toFixed(2)}`;
  }
}
function toggleNews() {
  const newsBoard = document.getElementById('newsBoard');
  if (newsBoard.style.display === 'flex') {
    newsBoard.style.display = 'none';
  } else {
    newsBoard.style.display = 'flex';

    // Mark news as read when opened
    fetch('http://10.110.110.53:3000/news/read', { method: 'POST' })
      .then(response => response.json())
      .then(data => {
        const newsCountElement = document.getElementById('newsCount');
        newsCountElement.innerHTML = data.unreadCount;
        newsCountElement.style.display = data.unreadCount > 0 ? 'inline' : 'none';
      })
      .catch(error => console.error('Error marking news as read:', error));
  }
}

function fetchNews() {
  fetch('http://10.110.110.53:3000/news') // Ensure this matches your server URL
    .then(response => response.json())
    .then(data => {
        const unreadCount = data.unreadCount;
        const newsCountElement = document.getElementById('newsCount'); 
        newsCountElement.innerHTML = unreadCount;
        newsCountElement.style.display = unreadCount > 0 ? 'inline' : 'none';

        // Update the news list
        const newsList = document.getElementById('newsList');
        newsList.innerHTML = ''; // Clear previous news
        data.news.forEach(item => {
            const newsItem = document.createElement('li');
            newsItem.innerText = `${item.timestamp}: ${item.message}`;
            newsList.appendChild(newsItem);
        });
    })
    .catch(error => console.error('Error fetching news:', error));
}
