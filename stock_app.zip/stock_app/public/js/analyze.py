import pandas as pd

# Load your data (replace with your file path)
data = pd.read_csv("C:\\Users\\Admin\\Desktop\\stock_app\\data\\Falcon Biotech.csv")

# Convert the time index (if you have timestamps or seconds)
# Assuming each row represents 1 second, you can create a datetime index starting from 10:00 AM.
data['Time'] = pd.date_range(start="10:00", periods=len(data), freq='S')
data.set_index('Time', inplace=True)

# Resample the data to a larger time interval, e.g., 30 minutes
resampled_data = data['Stock Value'].resample('30T').mean()  # Resampling every 30 minutes ('30T')

# Calculate percentage change over the 30-minute intervals
resampled_data = resampled_data.pct_change() * 100

# Identify significant changes (adjust thresholds as needed)
significant_rise = 1.0  # for major rise
significant_fall = -1.0  # for major fall

# Generate news events based on trends in the resampled data
news = []
for time, change in resampled_data.items():  # Use items() instead of iteritems()
    if pd.isna(change):
        continue
    if change >= significant_rise:
        news.append(f"At {time.strftime('%H:%M')}: Stock Rises Sharply by {change:.2f}%.")
    elif change <= significant_fall:
        news.append(f"At {time.strftime('%H:%M')}: Stock Plummets by {change:.2f}%.")
    elif 0.5 <= change < significant_rise:
        news.append(f"At {time.strftime('%H:%M')}: Stock Shows Steady Growth of {change:.2f}%.")
    elif significant_fall < change <= -0.5:
        news.append(f"At {time.strftime('%H:%M')}: Stock Dips Slightly by {change:.2f}%.")

# Display the generated news
for event in news[:6]:  # limiting to 6 news items
    print(event)
