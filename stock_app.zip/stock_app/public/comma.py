import csv

def csv_to_comma_separated_format(csv_file):
    values = []
    # Open the CSV file and read the values
    with open(csv_file, newline='') as file:
        reader = csv.reader(file)
        for row in reader:
            for row in reader:
            # Convert each value to a float, round to 3 decimal places, and convert back to string
                rounded_values = [str(round(float(value), 3)) for value in row]
                values.extend(rounded_values)   # Add each row's values to the list

    # Convert the list to a comma-separated string
    comma_separated_values = ','.join(values)
    return comma_separated_values

# Usage
csv_file_path = "C:\\Users\\Admin\\Desktop\\stock_app\\data\\Falcon Biotech.csv";  # Replace with your actual CSV file path
result = csv_to_comma_separated_format(csv_file_path)

# Print the comma-separated values
print(result)
