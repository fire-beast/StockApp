const express = require('express');
const fs = require('fs');
const csv = require('csv-parser');
const path = require('path');
const cors = require('cors'); // Import cors
const app = express();
const PORT = process.env.PORT || 3000;
// Enable CORS
app.use(cors());
// Parse URL-encoded bodies (for form submissions)
app.use(express.urlencoded({ extended: true }));
// Serve static files (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));
// Object to hold stock data and track the current index for each company
let newsData = [];
let unreadNotifications = 0;

// Define specific news items with timestamps
const scheduledNews = [
  { time: '10:39', message: "Global link awarded with contract to provide 5g infrastructure nationwide" },
  { time: '10:36', message: "Iron Ore increases its Infrastructure spending." },
  { time: '10:37', message: "Ai Nexus signs a strategic deal with Google to provide integrated cloud services" },
  { time: '10:42', message: "Vedant institute shares dip due to data corruption" },
  { time: '10:45', message: "multiple key client of Ai Nexus simultaneously terminate their contracts" },
  { time: '10:47', message: "Vedant Institute develops drug for monkey pox vaccine" },
  { time: '10:56', message: "Iron Ore remains stable at its position." },
  { time: '10:59', message: "Infosys announces partnership with Microsoft to develop Ai Powered enterprise solutions" },
  { time: '12:01', message: "A critical failure in Ai Nexus's supply chain leads to global project delays,costing company millions in penalties" },
  { time: '13:00', message: "Ai Nexus secures a multi-billion dollar contract to overhaul IT infrastructure for European Government to gain back investors trust" },
  { time: '13:22', message: "Ai Nexus's CEO steps down following serious fraud allegation,causing government crisis" },
  { time: '13:48', message: "Ai Nexus secures a multi-year contract to manage NASA's IT infrastructure" },
  { time: '14:54', message: "Ai Nexus unveils a breakthrough in quantum computing,positioning itself as global leaders in next-gen technology" },
  { time: '10:45', message: "Avro experiences quality control issues in Packaging line" },
  { time: '11:18', message: "Avro faces selling pressure as Raw Material's prices soar" },
  { time: '11:57', message: "Avro faces huge setback as people discover defect in Avro's product." },
  { time: '12:25', message: "strategic partnerships enhance market position of Avro" },
  { time: '12:58', message: "Avro's price drop due to entry of competition in market" },
  { time: '13:06', message: "Avro recovers nicely because of product diversification" },
  { time: '13:38', message: "Avro's sales aren't upto mark, product is not upto trend" },
  { time: '13:47', message: "Avro reports significant losses Amidst industry slowdown" },
  { time: '13:57', message: "Avro's technological upgrades result in operational efficiency gain" },
  { time: '14:26', message: "Avro's market challenges leads to significant losses" },
  { time: '11:14', message: "Global link announces minor delay in its project due to supply chain issues" },
  { time: '11:21', message: "Vedant's Drug contained side-effects" },
  { time: '11:37', message: "Vedant Institute faces bankcruptcy as the company spent all the funds on drug" },
  { time: '12:11', message: "death of CEO of Vedant Institute" },
  { time: '12:43', message: "Vedant Institute sold to rival company" },
  { time: '13:22', message: "income tax department raids on Vedant Institute's head office" },
  { time: '13:51', message: "Vedant Institute designs a new therapy to treat monkey pox patients" },
  { time: '14:28', message: "Vedant Institute's data center caught fire" },
  { time: '11:31', message: "Global link faces huge technical failure causing huge financial losses." },
  { time: '10:40', message: "Transworld Energy Announces New Solar Power Initiative, Stock Rises Steadily" },
  { time: '10:51', message: "Falcon Biotech faces setback after negative market rumours" },
  { time: '11:02', message: "Falcon Biotech Announces Breakthrough in Drug Development" },
  { time: '10:58', message: "Tomato launches Drone delivery service." },
  { time: '11:10', message: "Minor Delays in Solar Project,says the Transworld energy's CEO" },
  { time: '11:31', message: "Falcon Biotech recieves funding of total 5 crores from angel investors" },
  { time: '11:40', message: "Transworld Energy Holds Steady Amid Industry Competition." },
  { time: '12:02', message: "Falcon Biotech CEO Resigns Abruptly Amid Internal Conflicts" },
  { time: '11:59', message: "Global link introduces enhanced 4g services." },
  { time: '12:33', message: "Global link launches new pricing plans." },
  { time: '11:52', message: "Tomato Hit by Massive Data breach." },
  { time: '12:36', message: "Tomato reports record monthly orders!" },
  { time: '12:42', message: "Falcon Biotech Signs Major Partnership with Global Pharma" },
  { time: '13:09', message: "Regulatory Scrutiny on Biotech Sector Intensifies, Falcon Biotech Stock Falls by 16.12%." },
  { time: '13:22', message: "Global link's growth is slightly below projections for quarter." },
  { time: '13:32', message: "Falcon Biotech Reports Record Profits in Q2 Earnings" },
  { time: '13:40', message: "Transworld signs Major Partnership Deal with Global Power Corp" },
  { time: '13:37', message: "Tomato workers go on strike over wages." },
  { time: '13:52', message: "Global link's network faces massive congestion and slow speeds." },
  { time: '14:07', message: "Tomato faces increased competition." },
  { time: '14:10', message: "Transworld's Profit-Taking Leads to Sharp Decline After Recent Surge." },
  { time: '14:13', message: "Global link plans to expand its fiber optic network to enhance broadband offerings." },
  { time: '14:37', message: "Tomato partners with major fast food chain!" },
  { time: '14:40', message: "Transworld Energy Stock Stabilizes After Volatile Trading" },
  { time: '14:45', message: "Falcon Biotech Reports Serious Safety Concerns in Latest Clinical Trials" },
  { time: '14:57', message: "Transworld's Positive Quarterly Earnings Report Sparks Renewed Growth" },
  { time: '10:57', message: "Infotech Company gets breakthrough in Ai Development" },
  { time: '11:11', message: "Infotech rises due to Ai patent approval" },
  { time: '12:35', message: "Infotech's price fall due to rising development costs" },
  { time: '13:04', message: "strong demand for Automation Products " },
  { time: '13:47', message: "Infotech recovers after securing major renewable energy contract" },
  { time: '10:49', message: "people keep an eye on Ramesh retail as global shipping costs push profits higher  " },
  { time: '11:16', message: "supply chain inefficiencies lead to price cut of Ramesh Retail" },
  { time: '13:03', message: "Ramesh Retail in danger because of supply chain disruptions" },
  { time: '14:36', message: "Ramesh Retail's price increases as energy prices lead to cost pass through" },
];
// Function to check if it's time to send news
function checkNewsSchedule() {
  const now = new Date();
  const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  
  // Check if any scheduled news should be sent
  scheduledNews.forEach(item => {
    if (item.time === currentTime) {
      newsData.push({ timestamp: now.toLocaleString(), message: item.message });
      unreadNotifications++;
    }
  });
}
// API to mark news as read
app.post('/news/read', (req, res) => {
  if (unreadNotifications > 0) {
    unreadNotifications=0; // Decrement the unread notification count
  }
  res.json({ unreadCount: unreadNotifications });
});
// Call checkNewsSchedule every minute
setInterval(checkNewsSchedule, 60000);

// API to get news data and unread notifications count
app.get('/news', (req, res) => {
  res.json({
    news: newsData,
    unreadCount: unreadNotifications
  });
});
function removeEarliestNews() {
  if (newsData.length > 0) {
      newsData.shift(); // Removes the first (oldest) item in the array
      console.log('Earliest news removed');
  }
}

// Schedule to run every 7 minutes
setInterval(removeEarliestNews, 600000);
let stockData = {};
let currentIndex = {};
// Initialize stockData and currentIndex for each company
function initializeCompanies(companies) {
  companies.forEach((company) => {
    stockData[company] = [];
    currentIndex[company] = 0;
    readStockData(company);
  });
}

// Read the CSV file for each company and store the data in memory
function readStockData(company) {
  const csvFilePath = path.join(__dirname, `data/${company}.csv`);
  const stockValues = {
    "IronOre": [],
    "Vedant Institute": [],
    "Ramesh Retail": [],
    "Global Link ISP": [],
    "AI Nexus Technologies": [],
    "InfoTech Technologies": [],
    "Avro India Limited": [],
    "Falcon Biotech": [],
    "Tomato": [],
    "Transworld Energy": [],
  };

  fs.createReadStream(csvFilePath)
    .pipe(csv())
    .on('data', (row) => {
      stockValues[company].push(row['Stock Value']);
    })
    .on('end', () => {
      stockData[company] = stockValues[company];
      console.log(`Finished reading ${company} stock data`);
    })
    .on('error', (error) => {
      console.error(`Error reading ${company} data: `, error);
    });
}

// Function to check if the current time is within market hours (10:00 AM to 3:00 PM)
function isMarketOpen() {
  const now = new Date();
  const start = new Date();
  const end = new Date();
  
  start.setHours(10, 35, 0); // 10:30 AM
  end.setHours(15, 0, 0); // 3:00 PM

  return now >= start && now <= end;
}

// Update the stock prices by advancing the index every second if the market is open
function updateStockPrices(companies) {
  if (isMarketOpen()) {
    companies.forEach((company) => {
      if (stockData[company].length > 0) {
        currentIndex[company] = (currentIndex[company] + 1) % stockData[company].length;
      }
    });
  } else {
    console.log("Market is closed. No updates to stock prices.");
  }
}

// Call updateStockPrices every second
setInterval(() => {
  updateStockPrices(Object.keys(stockData));
}, 1000);

// Serve the login page at the root
app.get('/', function (req, res) {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Handle login form submission
app.post('/login', function (req, res) {
  // For simplicity, assume login is successful
  const username = req.body.username; // Get username from form input
  const password = req.body.password; // Get password from form input

  // Validate the username and password if needed (not implemented here)

  // Redirect to home.html after successful login
  res.redirect('/home');
});

// Serve the home page after login
app.get('/home', function (req, res) {
  res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

// Serve the stock simulator (index.html) when clicking the simulator button
app.get('/simulator', function (req, res) {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API to send the current stock price for each company to the frontend
app.get('/stock-data', (req, res) => {
  const response = {};
  Object.keys(stockData).forEach((company) => {
    if (stockData[company].length > 0) {
      response[company] = stockData[company][currentIndex[company]];
    }
  });
  res.json(response);
});

// Start the server
app.listen(PORT, () => {
  const companies = [
    'IronOre', 'Vedant Institute', 'Ramesh Retail',
    'Global Link ISP', 'AI Nexus Technologies', 'InfoTech Technologies',
    'Avro India Limited', 'Falcon Biotech', 'Tomato', 'Transworld Energy'
  ];
  initializeCompanies(companies);
  console.log(`Server is running on port ${PORT}`);
});